import { McpServer, ResourceTemplate } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';

export function createMcpServer(kernel, browserPool, { paperKernel, paperContentKernel, deepResearchKernel, paperCacheStore, paperCacheCleanup } = {}) {
  const server = new McpServer(
    {
      name: 'local-search-mcp',
      version: '0.1.0',
      description: 'Local Search & Web Evidence service — search the web and fetch pages without a paid search API.'
    },
    {
      capabilities: {
        tools: { listChanged: true },
        resources: { listChanged: true },
        prompts: {}
      },
      instructions: (() => {
        const lines = [
          'Local Search & Academic Paper MCP',
          '',
          'Core tools: search_web, fetch_page, search_and_fetch, research_problem, get_artifact, engine_status',
        ];
        if (paperKernel) {
          lines.push('', 'Paper tools (ENABLE_PAPER_TOOLS=true): search_papers, lookup_paper, expand_paper_citations, find_open_access, research_papers');
          if (paperContentKernel) {
            lines.push('Content tools: locate_paper_content, fetch_paper_content, get_paper_sections');
          }
        }
        if (deepResearchKernel) {
          lines.push('', 'Deep research tool: research_deep');
        }
        lines.push('', 'Quick start:',
          '  - Use search_web to search DuckDuckGo + Wikipedia via HTTP (no login, no browser needed).',
          '  - To use Google, Bing, or ChatGPT, add them to engines[] explicitly.',
          '  - Browse-dep engines require prior login via noVNC browser (http://localhost:6082).',
          '  - The browser is automatically closed after each query.',
          '  - Use fetch_page to extract clean text from any URL.',
          '  - Use search_papers to search academic sources (requires API keys).');
        return lines.join('\n');
      })()
    }
  );

  function textContent(text) {
    return { content: [{ type: 'text', text }] };
  }

  function jsonContent(data) {
    return textContent(JSON.stringify(data, null, 2));
  }

  function errorContent(message, details) {
    return {
      content: [{ type: 'text', text: details ? `${message}\n${JSON.stringify(details, null, 2)}` : message }],
      isError: true
    };
  }

  function withTimeout(promise, ms) {
    const timer = new Promise((_, reject) => {
      const id = setTimeout(() => {
        const err = new Error(`Timed out after ${ms}ms`);
        err.code = 'TIMEOUT';
        reject(err);
      }, ms);
      promise.then(() => clearTimeout(id), () => clearTimeout(id)).catch(() => {});
    });
    return Promise.race([promise, timer]);
  }

  function wrapHandler(handler) {
    return async (args, extra) => {
      try {
        return await handler(args, extra);
      } catch (err) {
        const msg = err?.message || String(err);
        const details = err?.details || err?.code ? { code: err.code, ...err.details } : undefined;
        return errorContent(msg, details);
      }
    };
  }

  const toolSchemas = [];

  function registerCoreTool(name, description, inputSchema, handler) {
    server.tool(name, description, inputSchema, wrapHandler(handler));
    const jsSchema = { type: 'object', properties: {}, required: [] };
    for (const [k, v] of Object.entries(inputSchema)) {
      if (!v || typeof v !== 'object') continue;
      const def = v._def || {};
      const isOptional = def.typeName === 'ZodOptional';
      const innerDef = isOptional ? (def.innerType?._def || def) : def;
      let type = 'string';
      if (innerDef.typeName === 'ZodNumber') type = 'number';
      else if (innerDef.typeName === 'ZodBoolean') type = 'boolean';
      else if (innerDef.typeName === 'ZodArray') type = 'array';
      else if (innerDef.typeName === 'ZodObject') type = 'object';
      const desc = def.description || innerDef.description || '';
      jsSchema.properties[k] = { type, description: desc };
      if (!isOptional) jsSchema.required.push(k);
    }
    toolSchemas.push({ name, description, inputSchema: jsSchema });
  }

  function browserEngines(args) {
    return args?.engines?.filter?.(e => e === 'google' || e === 'bing' || e === 'chatgpt') || [];
  }

  async function closeBrowserAfterSearch(args) {
    const usedBrowserEngines = browserEngines(args);
    if (usedBrowserEngines.length === 0) return;
    const hasInteractivePage = usedBrowserEngines.some(e => {
      const s = e === 'chatgpt' ? 'chatgpt' : e;
      return browserPool.sessionStatus(s)?.interactive_page_url;
    });
    if (!hasInteractivePage) {
      await browserPool.close().catch(() => {});
    }
  }

  registerCoreTool('search_web',
    'Search DuckDuckGo, Wikipedia, or custom HTML engines. Returns up to 20 search results with snippets. To use Google/Bing/ChatGPT, specify them explicitly in engines[] — they require prior login via noVNC (http://localhost:6082). No paid API required.',
    {
      query: z.string().min(1).describe('Search query'),
      limit: z.number().int().min(1).max(20).optional().describe('Max results (default: 10, max: 20)'),
      engines: z.array(z.string()).optional().describe('Engines: default uses DuckDuckGo + Wikipedia (HTTP, no login). Add "google", "bing", or "chatgpt" explicitly if logged in.'),
      proxy_profile: z.string().optional().describe('Proxy profile name (default: "auto")')
    },
    async (args) => {
      const result = await withTimeout(kernel.searchWeb(args), 45000);
      await closeBrowserAfterSearch(args);
      return jsonContent(result);
    }
  );

  registerCoreTool('fetch_page',
    'Fetch a URL and return extracted plain text. Falls back to Playwright browser if HTTP fetch fails. Results stored as artifact for chunked reading.',
    {
      url: z.string().url().describe('URL to fetch'),
      mode: z.enum(['auto', 'http', 'browser']).optional().describe('Fetch mode: auto (try http then browser), http, or browser'),
      proxy_profile: z.string().optional().describe('Proxy profile name'),
      max_chars: z.number().int().min(1000).max(100000).optional().describe('Max characters to extract')
    },
    async (args) => jsonContent(await kernel.fetchPage(args))
  );

  registerCoreTool('search_and_fetch',
    'Search the web and fetch the top result pages sequentially. Failed pages are skipped automatically. Returns an EvidenceBundle with text previews and artifact references.',
    {
      query: z.string().min(1).describe('Search query'),
      limit: z.number().int().min(1).max(20).optional().describe('Max search results per engine'),
      fetch_top_k: z.number().int().min(1).max(20).optional().describe('Number of result pages to fetch'),
      max_chars_total: z.number().int().min(2000).max(200000).optional().describe('Total max chars across all fetched pages'),
      proxy_profile: z.string().optional().describe('Proxy profile name')
    },
    async (args) => {
      const result = await withTimeout(kernel.searchAndFetch(args), 60000);
      await closeBrowserAfterSearch(args);
      return jsonContent(result);
    }
  );

  registerCoreTool('research_problem',
    'Generate query families from a problem signature, search multiple engines, fetch evidence pages, and return structured evidence candidates with confidence scores. Ideal for debugging, issue investigation, and technical research.',
    {
      problem_signature: z.object({
        task: z.string().optional(),
        symptom: z.string().optional(),
        error_message: z.string().optional(),
        environment: z.any().optional(),
        constraints: z.array(z.string()).optional()
      }).describe('Problem description with task, symptom, error, environment, and constraints'),
      budget: z.object({
        max_queries: z.number().int().min(1).max(6).optional(),
        max_results_per_query: z.number().int().min(1).max(20).optional(),
        max_pages: z.number().int().min(1).max(20).optional(),
        max_chars_total: z.number().int().min(5000).max(200000).optional()
      }).optional().describe('Research budget controls'),
      source_policy: z.object({
        prefer: z.array(z.string()).optional(),
        proxy_profile: z.string().optional()
      }).optional().describe('Source preference and network policy')
    },
    async (args) => jsonContent(await kernel.researchProblem(args))
  );

  registerCoreTool('get_artifact',
    'Read a stored artifact (search results, fetched page, bundle) in bounded chunks. Use the artifact_ref returned by other tools.',
    {
      artifact_ref: z.string().describe('Artifact reference (e.g. artifact://search/search_xxx.txt)'),
      offset: z.number().int().min(0).optional().describe('Byte offset to start reading from'),
      limit: z.number().int().min(1).max(100000).optional().describe('Max bytes to read (default: 8000)')
    },
    async (args) => jsonContent(kernel.getArtifact(args))
  );

  registerCoreTool('engine_status',
    'Return available search engines, proxy profiles, browser session status, and rate limits.',
    {},
    async () => jsonContent(kernel.engineStatus())
  );

  server.registerResource(
    'Artifact',
    new ResourceTemplate('artifact://{kind}/{file}', {
      list: async () => {
        return { resources: [] };
      }
    }),
    {
      description: 'Stored artifact from search or page fetch operations',
      mimeType: 'text/plain'
    },
    async (uri, variables) => {
      const ref = `artifact://${variables.kind}/${variables.file}`;
      const data = kernel.getArtifact({ artifact_ref: ref, offset: 0, limit: 100000 });
      return {
        contents: [{
          uri: uri.href,
          mimeType: 'text/plain',
          text: data.text
        }]
      };
    }
  );

  server.registerPrompt('search_and_summarize', {
    title: 'Search and Summarize',
    description: 'Search for a topic and summarize findings from the top results',
    argsSchema: {
      topic: z.string().describe('Topic to research and summarize')
    }
  }, async (args) => ({
    messages: [{
      role: 'user',
      content: {
        type: 'text',
        text: `Please search the web for information about "${args.topic}" and provide a concise summary. Use search_web and fetch_page tools to gather information from at least 3 different sources.`
      }
    }]
  }));

  server.registerPrompt('debug_error', {
    title: 'Debug an Error',
    description: 'Research an error message or technical problem and find solutions',
    argsSchema: {
      error_message: z.string().describe('The error message or problem description'),
      environment: z.string().optional().describe('Environment details (OS, version, framework, etc.)')
    }
  }, async (args) => ({
    messages: [{
      role: 'user',
      content: {
        type: 'text',
        text: [
          `I need help debugging the following error:`,
          ``,
          `${args.error_message}`,
          args.environment ? `\nEnvironment: ${args.environment}\n` : '',
          ``,
          `Please research this error thoroughly. Use research_problem with a detailed problem_signature to search multiple sources. Look for official docs, GitHub issues, and StackOverflow answers. Provide the root cause, reproduction steps, and at least one working solution.`
        ].join('\n')
      }
    }]
  }));

  // ─── Paper tools (Phase C) ──────────────────────────────────────
  if (paperKernel) {
    const paperToolSchemas = [];

    function pw(handler) {
      return async (args) => {
        try { return jsonContent(await handler(args)); }
        catch (err) { return errorContent(err?.message || String(err), err?.details); }
      };
    }

    function addPaperTool(name, description, rawShape, handler) {
      server.tool(name, description, rawShape, pw(handler));
      const httpSchema = buildJsonSchemaFromShape(rawShape);
      paperToolSchemas.push({ name, description, inputSchema: httpSchema });
    }

    function buildJsonSchemaFromShape(shape) {
      const props = {};
      const required = [];
      for (const [k, v] of Object.entries(shape)) {
        if (!v || typeof v !== 'object') continue;
        const def = v._def || {};
        const isOptional = def.typeName === 'ZodOptional';
        const innerDef = isOptional ? (def.innerType?._def || def) : def;
        let type = 'string';
        if (innerDef.typeName === 'ZodNumber') type = 'number';
        else if (innerDef.typeName === 'ZodBoolean') type = 'boolean';
        else if (innerDef.typeName === 'ZodArray') type = 'array';
        else if (innerDef.typeName === 'ZodObject') type = 'object';
        const desc = def.description || innerDef.description || '';
        props[k] = { type, description: desc };
        if (!isOptional) required.push(k);
      }
      return { type: 'object', properties: props, required };
    }

    addPaperTool('search_papers',
      'Search academic papers across OpenAlex, Semantic Scholar, arXiv, and Crossref. Returns deduplicated and ranked PaperRecord results.',
      {
        query: z.string().min(1).describe('Search query'),
        limit: z.number().int().min(1).max(100).optional().describe('Max results (default: 20)'),
        year_from: z.number().int().optional().describe('Start year'),
        year_to: z.number().int().optional().describe('End year'),
        domain: z.string().optional().describe('Research domain (ai_ml, math, physics, etc.)'),
        sources: z.array(z.string()).optional().describe('Source list (openalex, semantic_scholar, arxiv, crossref)'),
        open_access_only: z.boolean().optional().describe('Filter to OA papers only')
      },
      (args) => paperKernel.searchPapers(args)
    );

    addPaperTool('lookup_paper',
      'Look up a single paper by DOI, arXiv ID, OpenAlex ID, or Semantic Scholar ID. Returns enriched PaperRecord from multiple sources.',
      {
        identifier: z.string().min(1).describe('Paper identifier'),
        identifier_type: z.string().optional().describe('Hint: doi, arxiv, openalex, semantic_scholar'),
        sources: z.array(z.string()).optional().describe('Sources to query')
      },
      (args) => paperKernel.lookupPaper(args)
    );

    addPaperTool('expand_paper_citations',
      'Expand citation graph for a paper — fetch references, cited-by, and related works. Returns citation edges and PaperRecords.',
      {
        identifier: z.string().min(1).describe('Paper identifier (DOI, arXiv ID, etc.)'),
        direction: z.enum(['references', 'cited_by', 'both', 'related']).optional().describe('Citation direction'),
        limit: z.number().int().min(1).max(200).optional().describe('Max papers per direction'),
        sources: z.array(z.string()).optional().describe('Sources for citation data')
      },
      (args) => paperKernel.expandPaperCitations(args)
    );

    addPaperTool('find_open_access',
      'Find open access versions of a paper by DOI. Checks Unpaywall and OpenAlex for legal OA PDFs and landing pages.',
      {
        identifier: z.string().min(1).describe('DOI or paper identifier')
      },
      (args) => paperKernel.findOpenAccess(args)
    );

    addPaperTool('research_papers',
      'Deep paper research — generates multiple search queries from a research question, searches across academic sources, expands citations on key papers, and returns structured evidence.',
      {
        research_question: z.string().min(1).describe('Research question'),
        domain: z.string().optional().describe('Research domain (default: ai_ml)'),
        year_from: z.number().int().optional().describe('Start year'),
        year_to: z.number().int().optional().describe('End year'),
        budget: z.object({
          max_queries: z.number().int().min(1).max(10).optional(),
          max_papers: z.number().int().min(1).max(200).optional(),
          max_citation_expansions: z.number().int().min(0).max(50).optional()
        }).optional(),
        source_policy: z.object({
          include_preprints: z.boolean().optional(),
          open_access_only: z.boolean().optional()
        }).optional()
      },
      (args) => paperKernel.researchPapers(args)
    );

    // ─── Paper Content tools ───────────────────────────────────
    if (paperContentKernel) {
      addPaperTool('locate_paper_content',
        'Locate open access URLs for a paper by DOI or arXiv ID. Returns candidate URLs with source priority. Does not download anything.',
        {
          identifier: z.string().min(1).describe('DOI or arXiv ID'),
          identifier_type: z.string().optional().describe('Hint: doi or arxiv')
        },
        (args) => paperContentKernel.locateContent(args)
      );

      addPaperTool('fetch_paper_content',
        'Download and extract full text of a paper by DOI or arXiv ID. Caches raw PDF, text, sections, and chunks. Checks cache before downloading.',
        {
          identifier: z.string().min(1).describe('DOI or arXiv ID'),
          identifier_type: z.string().optional().describe('Hint: doi or arxiv'),
          paper_key: z.string().optional().describe('Override paper cache key (auto-derived if omitted)')
        },
        (args) => paperContentKernel.fetchContent(args)
      );

      addPaperTool('get_paper_sections',
        'Read cached sections and chunks for a paper. Use paper_key from fetch_paper_content result or identifier to look up.',
        {
          paper_key: z.string().optional().describe('Paper cache key'),
          identifier: z.string().optional().describe('DOI or arXiv ID (alternative to paper_key)'),
          identifier_type: z.string().optional().describe('Hint: doi or arxiv')
        },
        (args) => paperContentKernel.getSections(args)
      );
    }

    // ─── Deep Research tool (Phase D) ──────────────────────────────
    if (deepResearchKernel) {
      addPaperTool('research_deep',
        'Deep research combining web evidence and paper evidence. Generates sub-queries, searches web + academic sources, expands citations, fetches fulltext (optional), and builds a unified evidence pack with contradiction candidates.',
        {
          question: z.string().min(1).describe('Research question'),
          domain: z.string().optional().describe('Research domain (default: ai_ml)'),
          year_from: z.number().int().optional().describe('Start year'),
          year_to: z.number().int().optional().describe('End year'),
          budget: z.object({
            web_queries: z.number().int().min(1).max(8).optional(),
            paper_queries: z.number().int().min(1).max(8).optional(),
            max_web_pages: z.number().int().min(1).max(30).optional(),
            max_papers: z.number().int().min(1).max(200).optional(),
            max_citation_expansions: z.number().int().min(0).max(30).optional(),
            max_fulltext_papers: z.number().int().min(1).max(20).optional().describe('Max papers to fetch fulltext for (default 5)')
          }).optional(),
          source_policy: z.object({
            include_preprints: z.boolean().optional(),
            open_access_only: z.boolean().optional(),
            fetch_fulltext: z.boolean().optional().describe('If true, download & extract fulltext for top papers (default false)'),
            preserve_raw: z.boolean().optional().describe('If true, keep raw PDFs after extraction (default false)')
          }).optional(),
          proxy_profile: z.string().optional().describe('Proxy profile for web searches')
        },
        (args) => deepResearchKernel.researchDeep(args)
      );
    }

    toolSchemas.push(...paperToolSchemas);
  }

  // ─── Paper Cache tools (independent of paperKernel) ──────────
  if (paperCacheStore) {
    registerCoreTool('paper_cache_stats',
      'Show paper cache statistics: total items, size by variant, expired count, pinned items.',
      {},
      async () => paperCacheStore.stats()
    );

    registerCoreTool('paper_cache_cleanup',
      'Clean up expired paper cache files and enforce quota. Default dry_run=true — set dry_run=false to actually delete files.',
      {
        dry_run: z.boolean().optional().describe('If true (default), only report what would be deleted without actually removing.')
      },
      async (args) => {
        const dryRun = args.dry_run !== false;
        return paperCacheCleanup.cleanup(dryRun);
      }
    );
  }

  return { server, toolSchemas };
}
