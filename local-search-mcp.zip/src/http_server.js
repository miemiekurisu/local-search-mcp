import express from 'express';
import { randomUUID } from 'node:crypto';
import { CONFIG } from './config/index.js';
import { createKernel } from './app.js';
import { closeChromeDevtoolsMcpClient } from './browser/chromeDevtoolsMcpClient.js';
import { createMcpServer } from './mcp/server.js';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';

const { kernel, browserPool, toolRegistry, paperKernel, paperContentKernel, deepResearchKernel, paperCacheStore, paperCacheCleanup } = createKernel();
const { server: mcpServer, toolSchemas } = createMcpServer(kernel, browserPool, { paperKernel, paperContentKernel, deepResearchKernel, paperCacheStore, paperCacheCleanup });
const app = express();
app.use(express.json({ limit: '2mb' }));

function asyncRoute(fn) {
  return async (req, res) => {
    try {
      const result = await fn(req.body || req.query || {});
      res.json({ ok: true, result });
    } catch (err) {
      const errorObject = err && typeof err === 'object' ? err : {};
      res.status(500).json({
        ok: false,
        error: {
          code: errorObject.code || 'ERROR',
          message: errorObject.message || String(err),
          engine: errorObject.engine,
          details: errorObject.details,
          stack: process.env.NODE_ENV === 'production' ? undefined : errorObject.stack
        }
      });
    }
  };
}

const paperAsyncRoute = (kernelFn) => asyncRoute(async (args) => {
  if (!paperKernel) throw new Error('paper tools are disabled (ENABLE_PAPER_TOOLS=false)');
  return await kernelFn.call(paperKernel, args);
});

app.get('/health', (req, res) => res.json({ ok: true, name: 'local-search-mcp', version: '0.1.0' }));
app.get('/engine_status', asyncRoute(async () => kernel.engineStatus()));
app.get('/browser_sessions', asyncRoute(async () => kernel.browserSessions()));
app.post('/browser_sessions/open', asyncRoute(args => kernel.openBrowserSession(args)));
app.post('/browser_sessions/save', asyncRoute(args => kernel.saveBrowserSession(args)));
app.post('/search', asyncRoute(args => kernel.searchWeb(args)));
app.post('/fetch_page', asyncRoute(args => kernel.fetchPage(args)));
app.post('/search_and_fetch', asyncRoute(args => kernel.searchAndFetch(args)));
app.post('/research_problem', asyncRoute(args => kernel.researchProblem(args)));
app.post('/artifact', asyncRoute(args => kernel.getArtifact(args)));

// Paper tools REST endpoints
if (paperKernel) {
  app.post('/papers/search', paperAsyncRoute(paperKernel.searchPapers));
  app.post('/papers/lookup', paperAsyncRoute(paperKernel.lookupPaper));
  app.post('/papers/citations', paperAsyncRoute(paperKernel.expandPaperCitations));
  app.post('/papers/open_access', paperAsyncRoute(paperKernel.findOpenAccess));
  app.post('/papers/research', paperAsyncRoute(paperKernel.researchPapers));
  if (deepResearchKernel) {
    app.post('/research/deep', asyncRoute(async (args) => deepResearchKernel.researchDeep(args)));
  }
}

// Paper content REST endpoints
if (paperContentKernel) {
  app.post('/papers/content/locate', asyncRoute(async (args) => paperContentKernel.locateContent(args)));
  app.post('/papers/content/fetch', asyncRoute(async (args) => paperContentKernel.fetchContent(args)));
  app.post('/papers/content/sections', asyncRoute(async (args) => paperContentKernel.getSections(args)));
}

// Paper cache REST endpoints (independent of paperKernel)
if (paperCacheStore) {
  app.get('/papers/cache/stats', asyncRoute(async () => paperCacheStore.stats()));
  app.post('/papers/cache/cleanup', asyncRoute(async (args) => paperCacheCleanup.cleanup(args?.dry_run !== false)));
}

// MCP over HTTP — lightweight JSON-RPC endpoint using shared tool schemas
app.post('/mcp', async (req, res) => {
  try {
    const message = req.body;
    if (!message || !message.jsonrpc || !message.method) {
      return res.status(400).json({ jsonrpc: '2.0', error: { code: -32600, message: 'Invalid Request' }, id: null });
    }

    if (message.method === 'initialize') {
      return res.json({
        jsonrpc: '2.0',
        id: message.id,
        result: {
          protocolVersion: '2024-11-05',
          capabilities: { tools: { listChanged: true }, resources: { listChanged: true }, prompts: {} },
          serverInfo: { name: 'local-search-mcp', version: '0.1.0' },
          instructions: 'Web search, page fetch, and academic paper search tools. Use search_papers, lookup_paper, expand_paper_citations, find_open_access for academic research.'
        }
      });
    }

    if (message.method === 'tools/list') {
      let tools = toolSchemas;
      if (!paperKernel) {
        tools = toolSchemas.filter(t => !['search_papers','lookup_paper','expand_paper_citations','find_open_access','research_papers','research_deep','locate_paper_content','fetch_paper_content','get_paper_sections'].includes(t.name));
      }
      return res.json({ jsonrpc: '2.0', id: message.id, result: { tools } });
    }

    if (message.method === 'tools/call') {
      const { name, arguments: args } = message.params;
      let result;

      try {
        switch (name) {
          case 'search_web': {
            const r = await kernel.searchWeb(args || {});
            result = { content: [{ type: 'text', text: JSON.stringify(r, null, 2) }] };
            break;
          }
          case 'fetch_page': {
            const r = await kernel.fetchPage(args || {});
            result = { content: [{ type: 'text', text: JSON.stringify(r, null, 2) }] };
            break;
          }
          case 'search_and_fetch': {
            const r = await kernel.searchAndFetch(args || {});
            result = { content: [{ type: 'text', text: JSON.stringify(r, null, 2) }] };
            break;
          }
          case 'research_problem': {
            const r = await kernel.researchProblem(args || {});
            result = { content: [{ type: 'text', text: JSON.stringify(r, null, 2) }] };
            break;
          }
          case 'get_artifact': {
            const r = kernel.getArtifact(args || {});
            result = { content: [{ type: 'text', text: JSON.stringify(r, null, 2) }] };
            break;
          }
          case 'engine_status': {
            const r = kernel.engineStatus();
            result = { content: [{ type: 'text', text: JSON.stringify(r, null, 2) }] };
            break;
          }
          default: {
            let r;
            switch (name) {
              case 'search_papers':
                if (!paperKernel) throw new Error(`Unknown tool: ${name}`);
                r = await paperKernel.searchPapers(args || {}); break;
              case 'lookup_paper':
                if (!paperKernel) throw new Error(`Unknown tool: ${name}`);
                r = await paperKernel.lookupPaper(args || {}); break;
              case 'expand_paper_citations':
                if (!paperKernel) throw new Error(`Unknown tool: ${name}`);
                r = await paperKernel.expandPaperCitations(args || {}); break;
              case 'find_open_access':
                if (!paperKernel) throw new Error(`Unknown tool: ${name}`);
                r = await paperKernel.findOpenAccess(args || {}); break;
              case 'research_papers':
                if (!paperKernel) throw new Error(`Unknown tool: ${name}`);
                r = await paperKernel.researchPapers(args || {}); break;
              case 'research_deep':
                if (!deepResearchKernel) throw new Error('Deep research not available');
                r = await deepResearchKernel.researchDeep(args || {}); break;
              case 'paper_cache_stats':
                if (!paperCacheStore) throw new Error('Paper cache not available');
                r = paperCacheStore.stats(); break;
              case 'paper_cache_cleanup':
                if (!paperCacheCleanup) throw new Error('Paper cache not available');
                r = paperCacheCleanup.cleanup(args?.dry_run !== false); break;
              case 'locate_paper_content':
                if (!paperContentKernel) throw new Error(`Unknown tool: ${name}`);
                r = await paperContentKernel.locateContent(args || {}); break;
              case 'fetch_paper_content':
                if (!paperContentKernel) throw new Error(`Unknown tool: ${name}`);
                r = await paperContentKernel.fetchContent(args || {}); break;
              case 'get_paper_sections':
                if (!paperContentKernel) throw new Error(`Unknown tool: ${name}`);
                r = await paperContentKernel.getSections(args || {}); break;
              default:
                throw new Error(`Unknown tool: ${name}`);
            }
            result = { content: [{ type: 'text', text: JSON.stringify(r, null, 2) }] };
          }
        }
      } catch (err) {
        return res.json({
          jsonrpc: '2.0',
          id: message.id,
          error: { code: -32603, message: err.message || 'Internal error' }
        });
      }

      return res.json({ jsonrpc: '2.0', id: message.id, result });
    }

    if (message.method === 'resources/list') {
      return res.json({ jsonrpc: '2.0', id: message.id, result: { resources: [] } });
    }

    return res.json({
      jsonrpc: '2.0',
      id: message.id,
      error: { code: -32601, message: `Method not found: ${message.method}` }
    });
  } catch (err) {
    console.error('[mcp-http] error:', err);
    res.json({
      jsonrpc: '2.0',
      id: req.body?.id ?? null,
      error: { code: -32603, message: err.message || 'Internal error' }
    });
  }
});

// Also provide the stdio MCP server on a separate endpoint using StreamableHTTP
const mcpTransport = new StreamableHTTPServerTransport({
  sessionIdGenerator: () => randomUUID()
});
app.all('/mcp-stream', async (req, res) => {
  await mcpTransport.handleRequest(req, res, req.body);
});
mcpServer.connect(mcpTransport).catch(err => {
  console.error('[mcp-http] streamable transport connect error:', err);
});

const server = app.listen(CONFIG.port, '0.0.0.0', () => {
  console.log(`[local-search-mcp] HTTP server listening on :${CONFIG.port}`);
  console.log(`[local-search-mcp] MCP JSON-RPC endpoint: http://localhost:${CONFIG.port}/mcp`);
  console.log(`[local-search-mcp] MCP Streamable HTTP endpoint: http://localhost:${CONFIG.port}/mcp-stream`);
});

async function shutdown() {
  console.log('[local-search-mcp] shutting down');
  await closeChromeDevtoolsMcpClient().catch(() => {});
  await browserPool.close();
  server.close(() => process.exit(0));
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
